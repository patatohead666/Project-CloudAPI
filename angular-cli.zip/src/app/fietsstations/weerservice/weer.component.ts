import { Component, OnInit } from "@angular/core";
import { WeatherService, IWeatherResult } from '../../services/weather.service'
import * as mathjs from "mathjs"

@Component({
    selector: 'app-fietsstation-weer',
    templateUrl: './weer.component.html',
})



export class WeerComponent implements OnInit {
  
  data: IWeatherResult;
  rain: number[];
  average: number;
  
  constructor(private _svc: WeatherService) { }

  ngOnInit() {
    this._svc.getWeatherForDays(4).subscribe(result => this.extractData(result));
  }

  extractData(result: IWeatherResult){
    if(result!=null){                
      this.data = result;
    }

    this.rain = new Array(this.data.list.length);
    for(var i = 0; i<this.data.list.length; i++)
    {
      this.rain[i] = this.data.list[i].rain;
    }
    this.average = mathjs.mean(this.rain);
  }
}