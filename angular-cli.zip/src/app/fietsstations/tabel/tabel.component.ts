import { Component, OnInit } from "@angular/core";
import { VeloService, IVeloCollection} from '../../services/fietsstations.service'

@Component({
    selector: 'app-fietsstation-tabel',
    templateUrl: './tabel.component.html'
})

export class FietsstationTabel implements OnInit {

    stationData : iStationDetails[]
    _nr : number = 0;

    constructor(private _svc: VeloService) { }
  
    ngOnInit() {
      this._svc.getStation().subscribe(result => this.extractData(result));
    }

    extractData(result:IVeloCollection){
        if(result!=null){
            this.stationData = new Array(result.data.length)
            for(var i=0; i<result.data.length;i++){
                this.stationData[i] = ({
                    postcode: result.data[i].postcode,
                    straatnaam: result.data[i].straatnaam,
                    district: result.data[i].district,
                    status: result.data[i].gebruik,
                    grootte: result.data[i].type_velo,
                    huisnummer: result.data[i].huisnummer,
                    aanvulling: result.data[i].aanvulling,
                })
            }
        }
    }

    get ClickDropdown() {
        return this._nr;
    }

    set ClickDropdown(value: number) {
        this._nr = value;
    }
}

export interface iStationDetails{
    postcode: string;
    straatnaam: string;
    district: string;
    status: string;
    grootte: string;
    huisnummer: string;
    aanvulling: string;
 }