import { Component } from "@angular/core";

@Component({
    selector: 'app-fotos',
    templateUrl: './fotos.component.html'
})
export class FotosComponent
{
    
}