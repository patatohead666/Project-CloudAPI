import { Component, OnInit } from "@angular/core";
import { IwinkelstratenResult, Iwinkelstraat, WinkelStratenService } from '../../services/winkelstraten.service';


@Component({
    selector: 'app-informatie',
    templateUrl: './Informatie.component.html',
    styleUrls: ['./Informatie.component.scss']
})
export class InformatieComponent implements OnInit
{


    winkelstraten : Iwinkelstraat[];
    data: any[];
    _nr: number = 0;

    constructor(private _svc: WinkelStratenService){ }
    

    ngOnInit() {
        this._svc.getWinkelstraat().subscribe(result => this.extractData(result))
    }

    extractData(result: IwinkelstratenResult)
    {
        if(result != null)
        {
            this.data = result.data;
            this.winkelstraten = result.data;
        }
    }
    get select()
    {
        return this._nr
    }

    set select(value: number)
    {
        this._nr = value;
    }



}