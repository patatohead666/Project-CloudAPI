import { Component } from "@angular/core";

@Component({
    selector: 'app-intro',
    templateUrl: './intro.component.html'
})
export class IntroComponent
{

}