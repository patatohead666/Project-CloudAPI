import { Component, OnInit } from "@angular/core";
import { IwinkelstratenResult, WinkelStratenService } from '../../services/winkelstraten.service';

@Component({
    selector: 'app-gemiddelde',
    templateUrl: './gemiddelde.component.html',
    styleUrls: ['./gemiddelde.component.scss']
})
export class GemiddeldeComponent
{
    constructor(private _svc: WinkelStratenService){ }

    gemiddeldewinkelstraat: gemiddelden;
    
    themas: gem[] = new Array;//allemaal zelfde
    types: gem[] = new Array; //allemaal zelfde, nutteloos
    subtypes: gem[] = new Array;
    postcodes: gem[] = new Array;
    districten: gem[] = new Array;
    laagstes: gem[] = new Array;
    hoogstes: gem[] = new Array;
    lengte: number=0;
    shape_lengte: number=0;

    ngOnInit() {
        this._svc.getWinkelstraat().subscribe(result => this.extractData(result))
    }

    extractData(result: IwinkelstratenResult)
    {
        if(result != null)
        {
            let l: number = 0;
            let sl: number = 0;

            result.data.forEach(winkelstraat => {
                if(this.themas.findIndex(t => t.text == winkelstraat.thema)==-1)
                this.themas.push({text:winkelstraat.thema, count:0})
                else
                this.themas[this.themas.findIndex(t => t.text == winkelstraat.thema)].count++;

                if(this.types.findIndex(t => t.text == winkelstraat.type)==-1)
                this.types.push({text:winkelstraat.type, count:0})
                else
                this.types[this.types.findIndex(t => t.text == winkelstraat.type)].count++;

                if(this.subtypes.findIndex(t => t.text == winkelstraat.subtype)==-1)
                this.subtypes.push({text:winkelstraat.subtype, count:0})
                else
                this.subtypes[this.subtypes.findIndex(t => t.text == winkelstraat.subtype)].count++;

                if(this.postcodes.findIndex(t => t.text == winkelstraat.postcode)==-1)
                this.postcodes.push({text:winkelstraat.postcode, count:0})
                else
                this.postcodes[this.postcodes.findIndex(t => t.text == winkelstraat.postcode)].count++;

                if(this.districten.findIndex(t => t.text == winkelstraat.district)==-1)
                this.districten.push({text:winkelstraat.district, count:0})
                else
                this.districten[this.districten.findIndex(t => t.text == winkelstraat.district)].count++;

                if(this.laagstes.findIndex(t => t.text == winkelstraat.laagste_niveau)==-1)
                this.laagstes.push({text:winkelstraat.laagste_niveau, count:0})
                else
                this.laagstes[this.laagstes.findIndex(t => t.text == winkelstraat.laagste_niveau)].count++;

                if(this.hoogstes.findIndex(t => t.text == winkelstraat.hoogste_niveau)==-1)
                this.hoogstes.push({text:winkelstraat.hoogste_niveau, count:0})
                else
                this.hoogstes[this.hoogstes.findIndex(t => t.text == winkelstraat.hoogste_niveau)].count++;
                
                if(winkelstraat.lengte != null)
                {
                    this.lengte+= winkelstraat.lengte; //totaal lengte
                    l++;    //aantal winkelstraten met ingevulde lengte
                }
                if(winkelstraat.shape_length != null)
                {
                    this.shape_lengte+=parseInt(winkelstraat.shape_length);
                    sl++;
                }
            });
            this.lengte = this.lengte/l; //gemiddelde lengte
            this.shape_lengte = this.shape_lengte/sl;
            console.log(this.hoogstes)

        }
    }
}

export interface gemiddelden {
    thema: String;
    type: string;
    subtype: string;
    postcode: string;
    district: string;
    laagste_niveau: string;
    hoogste_niveau: string;
    lengte?: number;
    shape_length: string;
}

export interface gem{
    text: String;
    count: number;
}
/*


export interface Iwinkelstraat {
    objectid: number;
    geometry: string;
    geometry2: IGeometry;
    shape?: any;
    id: string;
    thema: string;
    type: string;
    subtype: string;
    naam: string;
    straatnaam?: string;
    postcode: string;
    district: string;
    laagste_niveau: string;
    hoogste_niveau: string;
    lengte?: number;
    shape_length: string;
  }
  */