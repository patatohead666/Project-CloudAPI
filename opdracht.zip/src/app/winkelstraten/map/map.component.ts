import { Component, OnInit } from "@angular/core";
import { AgmCoreModule, MouseEvent} from "@agm/core"
import { IwinkelstratenResult, Iwinkelstraat, WinkelStratenService } from '../../services/winkelstraten.service';

@Component({
    selector: 'app-map',
    templateUrl: './map.component.html',
    styleUrls: ['./map.component.scss']
})
export class MapComponent implements OnInit{

    latitude = 51.215;
    longitude = 4.414;

    aangekliktewinkelstraat: winkelstraat;

    markers : marker[];
    lines : any[][];//kinda works maar geen extra info

    winkelstraten : winkelstraat[];
    data: any[];

    constructor(private _svc: WinkelStratenService){ }
    
    onChoseLocation(event) {
        //this.latitude = event.coords.lat;
        //this.longitude = event.coords.lng;
    }
    ngOnInit() {
        this._svc.getWinkelstraat().subscribe(result => this.extractData(result))
    }


    winkelstraatklik(event: winkelstraat)
    {
        //console.log(event)
        this.aangekliktewinkelstraat = event;
    }   

    
    extractData(result : IwinkelstratenResult) {
        if(result!= null)
        {
            this.data = result.data;//just in case
            this.markers = new Array(result.data.length);
            
            let linelength = 0;
            for(var i = 0; i < result.data.length; i++)
            {
                result.data[i].geometry2.coordinates.forEach(lines => linelength += lines.length) //multiple lines in one coordinates[]
            }
            this.lines = new Array(linelength);
            
            for(var i = 0; i < result.data.length; i++){
                this.markers[i] = ({
                    
                    id : i,
                    lng: result.data[i].geometry2.coordinates[0][0][0],
                    lat: result.data[i].geometry2.coordinates[0][0][1],
                    label: result.data[i].id + " ",
                    draggable: false,
                    info:"adres: "+result.data[i].straatnaam + " "
                })
            }//markers eigenlijk niet nodig
            
            this.winkelstraten = new Array(result.data.length);
            for(var i = 0; i < result.data.length; i++)
            {
                let dstraten: straat[];
                dstraten = new Array(result.data[i].geometry2.coordinates.length);

                for(var j = 0; j< result.data[i].geometry2.coordinates.length; j++)
                {
                    let line = new Array(result.data[i].geometry2.coordinates[j].length); //line[] consists of points[lng, lat]
                    for(var k = 0; k<result.data[i].geometry2.coordinates[j].length; k++)
                    {
                        line[k] = {lng: result.data[i].geometry2.coordinates[j][k][0], lat: result.data[i].geometry2.coordinates[j][k][1]};
                    }
                    this.lines.push(line);

                    dstraten[j] = ({markering: line}) 
                }
                
                
                this.winkelstraten[i] = (
                    {
                        id: result.data[i].id,
                        straatnaam: result.data[i].straatnaam,
                        straten: dstraten
                    }
                )
            }
        }
        console.log(this.winkelstraten)
        console.log("end of extractdata")
    }


}

export interface winkelstraat {
    id: string;
    straatnaam?: string;
    straten: straat[];
}
export interface straat 
{
    markering: punt[];
}
export interface punt{
    lat: number;
    lng: number;
}

/*

export interface IGeometry {
    type: string;
    coordinates: number[][][];
}

export interface straat {
    id: string;
    thema: string;
    type: string;
    subtype: string;
    naam: string;
    straatnaam?: string;
    postcode: string;
    district: string;
    laagste_niveau: string;
    hoogste_niveau: string;
    lengte?: number;
    shape_length: string;
  }

*/
interface marker {
    id:number;
    lat: number;
    lng: number;
    label?: string;
    draggable: boolean;
    info?:string;
    distance?:number;
}