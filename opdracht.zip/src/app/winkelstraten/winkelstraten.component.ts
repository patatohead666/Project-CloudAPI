import { Component } from "@angular/core";

@Component({
    selector: 'app-winkelstraten',
    templateUrl: './winkelstraten.component.html',
    styles: ['.col { padding: 10px;} ']
})
export class WinkelstratenComponent 
{
    
}