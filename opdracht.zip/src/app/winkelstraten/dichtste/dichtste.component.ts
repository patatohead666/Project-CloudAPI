import { Component, OnInit } from "@angular/core";
import {AgmCoreModule, MouseEvent} from "@agm/core"
import { IwinkelstratenResult, Iwinkelstraat, WinkelStratenService } from '../../services/winkelstraten.service';
import { Marker, Polyline, PolygonOptions, LatLng } from '@agm/core/services/google-maps-types';
import {} from 'mathjs'

@Component({
    selector: 'app-dichtste',
    templateUrl: './dichtste.component.html',
    styleUrls: ['./dichtste.component.scss']
})
export class DichtsteComponent
{
    
    latitude:number = 51.215;
    longitude:number = 4.414;

    dichtstewinkelstraten : winkelstraat[];
    winkelstraten : winkelstraat[];
    data: any[];

    constructor(private _svc: WinkelStratenService){ }
    
    onChoseLocation(event) {
        this.latitude = event.coords.lat;
        this.longitude = event.coords.lng;
        //more stuff
        let distances: number[];
        distances = new Array(this.winkelstraten.length);

        let k:number=0;
        this.winkelstraten.forEach(winkelstraat => {
            winkelstraat.straten.forEach(straat => {
                straat.markeringen.forEach(punt => {
                    let dist:number= Math.sqrt( Math.pow(this.latitude - punt.lat,2) + Math.pow(this.longitude - punt.lng,2));
                    if(distances[k]== null || distances[k]>dist )
                    {
                        distances[k] = dist;
                    }
                });
            });
            k++;
        });
        let tmpdistances:number[] = new Array(5);
        for(var i =0; i<5;i++)
        {
            let tmp = 100;
            for(var j = 0; j < distances.length; j++)
            {
                if(distances[j]<tmp)
                {
                    if(tmpdistances[0]==null)
                    {
                        tmp = distances[j]
                    }
                    else
                    {
                        for(var l=0; l<5;l++)
                        {
                            if(tmpdistances[l+1]==null && tmpdistances[l]!=null && tmpdistances[l]<distances[j])
                            {
                                tmp = distances[j]
                            }
                                
                        }
                    }
                }
            }
            tmpdistances[i] = tmp;
        }

        this.dichtstewinkelstraten = new Array(5);
        for(var i =0; i<this.winkelstraten.length;i++)
        {
            for(var j =0; j<5; j++)
            {
                if(tmpdistances[j]==distances[i])
                this.dichtstewinkelstraten[j] = this.winkelstraten[i];
            }
        }

    }

    ngOnInit() {
        this._svc.getWinkelstraat().subscribe(result => this.extractData(result))
    }

    extractData(result : IwinkelstratenResult) {
        if(result!= null)
        {
            //this.data = result.data;//just in case
            
            let linelength = 0;
            for(var i = 0; i < result.data.length; i++)
            {
                result.data[i].geometry2.coordinates.forEach(lines => linelength += lines.length) //multiple lines in one coordinates[]
            }
            
            this.winkelstraten = new Array(result.data.length);
            for(var i = 0; i < result.data.length; i++)
            {
                let dstraten: straat[];
                dstraten = new Array(result.data[i].geometry2.coordinates.length);

                for(var j = 0; j< result.data[i].geometry2.coordinates.length; j++)
                {
                    let line = new Array(result.data[i].geometry2.coordinates[j].length); //line[] consists of points[lng, lat]
                    for(var k = 0; k<result.data[i].geometry2.coordinates[j].length; k++)
                    {
                        line[k] = {lng: result.data[i].geometry2.coordinates[j][k][0], lat: result.data[i].geometry2.coordinates[j][k][1]};
                    }

                    dstraten[j] = ({markeringen: line}) 
                }
                
                this.winkelstraten[i] = (
                    {
                        id: result.data[i].id,
                        straatnaam: result.data[i].straatnaam,
                        straten: dstraten
                    }
                )
            }
        }
    }
}

export interface winkelstraat {
    id: string;
    straatnaam?: string;
    straten: straat[];
}
export interface straat 
{
    markeringen: punt[];
}
export interface punt{
    lat: number;
    lng: number;
}
