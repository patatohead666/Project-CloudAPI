import { Component, OnInit } from "@angular/core";
import { WeatherService, IWeatherResult } from '../../services/weather.service'
import * as mathjs from "mathjs"

@Component({
    selector: 'app-fietsstation-weer',
    templateUrl: './weer.component.html',
})



export class WeerComponent implements OnInit {
  
  data: IWeatherResult;
  rain: number[];
  average: number;
  
  constructor(private _svc: WeatherService) { }

  ngOnInit() {
    this._svc.getWeatherForDays(4).subscribe(result => this.extractData(result));
    this.ifdatanull();
  }

  extractData(result: IWeatherResult){
    if(result!=null){                
      this.data = result;
    }

    this.rain = new Array(this.data.list.length);
    for(var i = 0; i<this.data.list.length; i++)
    {
      this.rain[i] = this.data.list[i].rain;
    }
    this.average = mathjs.mean(this.rain);
  }

  
  ifdatanull()
  {
    if(this.data==null)
    {
      this.data = ({"cod":"200","message":0,"city":{"coord":{"lat":5,"lon":5},"id":0,"name":"Antwerp (server resonse null, fake data)","country":"FAKEDATA","population":0},"cnt":10,"list":[{"rain":15, "dt":1485741600,"temp":{"day":285.51,"min":285.51,"max":285.51,"night":285.51,"eve":285.51,"morn":285.51},"pressure":1013.75,"humidity":100,"weather":[{"id":800,"main":"Clear","description":"sky is clear","icon":"01n"}],"speed":5.52,"deg":311,"clouds":0},{"rain":20,"dt":1485828000,"temp":{"day":282.27,"min":282.27,"max":284.66,"night":284.66,"eve":282.78,"morn":282.56},"pressure":1023.68,"humidity":100,"weather":[{"id":800,"main":"Clear","description":"sky is clear","icon":"01d"}],"speed":5.46,"deg":66,"clouds":0},{"rain":22,"dt":1485914400,"temp":{"day":284.83,"min":283.21,"max":285.7,"night":284.16,"eve":285.49,"morn":283.21},"pressure":1017.39,"humidity":100,"weather":[{"id":800,"main":"Clear","description":"sky is clear","icon":"02d"}],"speed":13.76,"deg":260,"clouds":8},{"rain":26,"dt":1486000800,"temp":{"day":283.71,"min":281.86,"max":285.13,"night":283.81,"eve":284.76,"morn":281.86},"pressure":1017.36,"humidity":100,"weather":[{"id":800,"main":"Clear","description":"sky is clear","icon":"01d"}],"speed":8.95,"deg":288,"clouds":0}]})
      
      this.rain = new Array(this.data.list.length);
      for(var i = 0; i<this.data.list.length; i++)
      {
        this.rain[i] = this.data.list[i].rain;
      }
      this.average = mathjs.mean(this.rain);
    }
  }
}