import { Component } from "@angular/core";

@Component({
    selector: 'app-fietsstation',
    templateUrl: './fietsstation.component.html',
    styles: ['.container{width: auto;}']
})
export class Fietsstation
{
    
}