import { Component, OnInit } from "@angular/core";
import { AirQualityService, RootObject} from '../../services/airquality.service';

@Component({
    selector: 'app-fietsstation-Luchtkwaliteit',
    templateUrl: './Luchtkwaliteit.component.html'
})

export class Luchtkwaliteit implements OnInit {
    AirQuality : iAirQuality

    constructor(private _svc: AirQualityService) { }
  
    ngOnInit() {
      this._svc.getAirQuality().subscribe(result => this.extractData(result));
    }
    
    extractData(result:RootObject){
        if(result!=null){                
            this.AirQuality = ({
                quality: result.breezometer_description,
                recommendationSport: result.random_recommendations.sport,
                recommendationChilderen: result.random_recommendations.children,
                effect: result.dominant_pollutant_text.effects
            })
        }
    }
}

export interface iAirQuality{
    quality: string;
    recommendationSport: string;
    recommendationChilderen: string;
    effect: string;
 }