import { Component, OnInit } from "@angular/core";
import { VeloService, IVeloCollection} from '../../services/fietsstations.service'

@Component({
    selector: 'app-fietsstation-map',
    templateUrl: './map.component.html',
    styleUrls: ['./map.component.css']
})
export class FietsstationMapComponent implements OnInit
{
    test : iStationDetails[]

    lat: number = 51.215;
    lng: number = 4.414;

    constructor(private _svc: VeloService) { }

    ngOnInit() {
        this._svc.getStation().subscribe(result => this.extractData(result));
    }

    extractData(result:IVeloCollection){
        if(result!=null){
            this.test = new Array(result.data.length)
            for(var i=0; i<result.data.length;i++){                
                this.test[i] = ({
                    latitude: parseFloat(result.data[i].point_lat),
                    longtitude: parseFloat(result.data[i].point_lng),
                    info: result.data[i].straatnaam
                })
            }
        }
    }
}

export interface iStationDetails {
    latitude: number;
    longtitude: number;
    info: string;
}